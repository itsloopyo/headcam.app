#!/bin/bash
set -e

BINARY="headcam-usb"
SOURCE="target/release/$BINARY"

if [ ! -f "$SOURCE" ]; then
    echo "Error: $SOURCE not found. Run 'pixi run build' first."
    exit 1
fi

case "$(uname -s)" in
    Darwin)
        INSTALL_DIR="/usr/local/bin"
        ;;
    Linux)
        INSTALL_DIR="/usr/local/bin"
        ;;
    MINGW*|MSYS*|CYGWIN*)
        INSTALL_DIR="$HOME/bin"
        mkdir -p "$INSTALL_DIR"
        ;;
    *)
        INSTALL_DIR="/usr/local/bin"
        ;;
esac

echo "Installing $BINARY to $INSTALL_DIR..."
cp "$SOURCE" "$INSTALL_DIR/$BINARY"
chmod +x "$INSTALL_DIR/$BINARY"
echo "Installed $INSTALL_DIR/$BINARY"
