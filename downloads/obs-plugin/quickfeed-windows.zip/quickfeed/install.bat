@echo off
echo Installing QuickFeed OBS Plugin...

set "PLUGIN_DIR=%ProgramData%\obs-studio\plugins\quickfeed"

:: Create plugin directory
if not exist "%PLUGIN_DIR%" mkdir "%PLUGIN_DIR%"

:: Copy files (script is in quickfeed folder after extraction)
xcopy /E /I /Y "%~dp0bin" "%PLUGIN_DIR%\bin"
xcopy /E /I /Y "%~dp0data" "%PLUGIN_DIR%\data"

echo.
echo Done! Plugin installed to:
echo %PLUGIN_DIR%
echo.
echo Restart OBS to use QuickFeed.
pause
